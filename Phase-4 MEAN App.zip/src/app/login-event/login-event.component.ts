import { Component, OnInit } from '@angular/core';
import {Router} from '@angular/router'
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-login-event',
  templateUrl: './login-event.component.html',
  styleUrls: ['./login-event.component.css']
})
export class LoginEventComponent implements OnInit {

  loginForm= new FormGroup({
    userName:new FormControl("",Validators.required),
    password:new FormControl("",[Validators.required,Validators.minLength(8)])
  })

  constructor(public router:Router) { }

  ngOnInit(): void {
    
  }
  loginEventHandler(){
    this.router.navigateByUrl("/start");
  }
}
